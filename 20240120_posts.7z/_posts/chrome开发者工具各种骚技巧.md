---
title: chrome开发者工具各种骚技巧
date: 2023-12-29 16:54:35
categories: 
  - web前端
tags: 
  - CSS
  - JS
---
## chrome开发者工具各种骚技巧

[原文](https://umaar.com/dev-tips/)
[原文](https://juejin.cn/post/6844903604839514125)

### 1.曾经，在线调伪类样式困扰过你？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/1.gif)

### 2.源代码快速定位到某一行！ctrl + p

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/2.gif)

### 3.联调接口失败时，后台老哥总管你要response？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/3.gif)

### 4.你还一层层展开dom？Alt + Click

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/4.gif)

### 5.是不是报错了，你才去打断点？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/5.gif)

### 6.你是不是经常想不起来，在哪绑定事件的？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/6.gif)

### 7.你是不是打断点时还要去改代码？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/7.gif)

### 8.看dom层级的最直观的方式？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/8.gif)

### 9.查一些特定的请求，过滤器用过吗？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/9.gif)

### 10.在Elements面板调整dom结构很不方便？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/10.gif)

###

### 11.想知道，某图片加载的代码在哪？Initiator！！

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/11.gif)

### 12.不想加载某个文件了？

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/chrome-f12-skills/12.gif)

多的就不列举了，可以看看开头的网站。看了有几个功能我电脑（win10）是没有的，应该跟chrome版本有关。

开发者工具的功能确实挺多，多得有时根本用不上，官网教程建议每个前端人员都看看：

[developers.google.com/web/tools/c…](https://developers.google.com/web/tools/chrome-devtools/)

中文版：

[www.css88.com/doc/chrome-…](http://www.css88.com/doc/chrome-devtools/)

\======================

补充：

见评论中多人问gif制作软件是什么。

搜索了一下，应该是[www.techsmith.com/](https://www.techsmith.com/)，看着说明，表示软件太专业。。

但我用过两个小软件很不错，非常容易上手：

* 录屏：[www.cockos.com/licecap/](https://www.cockos.com/licecap/)
* 屏幕放大：[docs.microsoft.com/zh-cn/sysin…](https://docs.microsoft.com/zh-cn/sysinternals/downloads/zoomit)

本文完。