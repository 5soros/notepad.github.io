---
title: CSS实现鼠标悬停后卡片上升并出现亮光特效
date: 2023-12-09 19:50:25
categories: 
  - 码海无涯
tags:
    - CSS
    - 码海无涯
---
### 码海无涯系列，写给自己的注释
### 码海无涯-CSS实现鼠标悬停后卡片上升并出现亮光特效

<P>
网上看到一个HTML代码，是鼠标悬停后卡片上升并出现亮光<br>
突发奇想改造了一下，左上角加了一个字，右下角也加了一个字<br>
令其能在鼠标悬停时，出现一个字<br>
看不懂的初学者，可以把<br>
.box1:transform: skew(-30deg) 和 .box的overflow: hidden<br>
注释掉，看看是怎么运作的<br><br>
知识点归纳：<br>

```css 
matrix(scaleX(),skewY(),skewX(),scaleY(),translateX(),translateY())
```

scaleX() (水平缩放)：控制元素水平方向的缩放。如果值为 1，则不进行水平缩放；如果大于 1，则放大；如果在 0 和 1 之间，则缩小。
skewY() (垂直倾斜)：控制元素在垂直方向上的倾斜。
skewX() (水平倾斜)：控制元素在水平方向上的倾斜。
scaleY() (垂直缩放)：控制元素垂直方向的缩放。如果值为 1，则不进行垂直缩放；如果大于 1，则放大；如果在 0 和 1 之间，则缩小。
translateX() (水平平移)：控制元素在水平方向上的平移量。
translateY() (垂直平移)：控制元素在垂直方向上的平移量。
即在不变换的情况下是matrix(1, 0, 0, 1, 0, 0)
</P>

<table class="reference" style="border: 0px; margin: 4px 0px; padding: 0px; border-collapse: collapse; width: 824.125px; color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, &quot;Noto Sans CJK SC&quot;, &quot;WenQuanYi Micro Hei&quot;, Arial, sans-serif; font-size: 11.25px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-transform: none; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; white-space: normal; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">
	<tbody style="border: 0px; margin: 0px; padding: 0px;">
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(246, 244, 240);">
			<th style="border: 1px solid rgb(85, 85, 85); margin: 0px; padding: 3px; font-size: 14px; color: rgb(255, 255, 255); background-color: rgb(85, 85, 85); vertical-align: top; text-align: left; width: 199.198px;">
			函数</th>
			<th style="border: 1px solid rgb(85, 85, 85); margin: 0px; padding: 3px; font-size: 14px; color: rgb(255, 255, 255); background-color: rgb(85, 85, 85); vertical-align: top; text-align: left;">
			描述</th>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(255, 255, 255);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			matrix(<i>n</i>,<i>n</i>,<i>n</i>,<i>n</i>,<i>n</i>,<i>n</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 转换，使用六个值的矩阵。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(246, 244, 240);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			translate(<i>x</i>,<i>y</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 转换，沿着 X 和 Y 轴移动元素。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(255, 255, 255);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			translateX(<i>n</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 转换，沿着 X 轴移动元素。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(246, 244, 240);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			translateY(<i>n</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 转换，沿着 Y 轴移动元素。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(255, 255, 255);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			scale(<i>x</i>,<i>y</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 缩放转换，改变元素的宽度和高度。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(246, 244, 240);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			scaleX(<i>n</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 缩放转换，改变元素的宽度。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(255, 255, 255);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			scaleY(<i>n</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 缩放转换，改变元素的高度。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(246, 244, 240);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			rotate(<i>angle</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 旋转，在参数中规定角度。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(255, 255, 255);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			skew(<i>x-angle</i>,<i>y-angle</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 倾斜转换，沿着 X 和 Y 轴。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(246, 244, 240);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			skewX(<i>angle</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 倾斜转换，沿着 X 轴。</td>
		</tr>
		<tr style="border: 0px; margin: 0px; padding: 0px; background-color: rgb(255, 255, 255);">
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; min-width: 24px; line-height: 2em; vertical-align: top;">
			skewY(<i>angle</i>)</td>
			<td style="border: 1px solid rgb(212, 212, 212); margin: 0px; padding: 7px 5px; font-size: 14px; line-height: 2em; min-width: 24px; vertical-align: top;">
			定义 2D 倾斜转换，沿着 Y 轴。</td>
		</tr>
</table>

![截图](https://raw.githubusercontent.com/5soros/blogs-photos/main/Ma-hai-wu-ya/a2.gif "代码效果示例")


```markup
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .box {
            overflow: hidden;
            position: relative;
            width: 300px;
            height: 300px;
            border: 1px solid #000;
            background-color: pink;
            margin: 100px auto;
            transition: all .1s;
        }

        .box1 {
            position: relative;
            position: absolute;
            left: -110%;
            top: 0;
            width: 300px;
            height: 300px;
            background-color: pink;
            background-image: linear-gradient(130deg, rgba(255, 255, 255, 0), rgba(255, 255, 255, .5), rgba(255, 255, 255, 0));
            transform: skew(-30deg) 
            /* skew(x-angle,y-angle)	定义沿着 X 和 Y 轴的 2D 倾斜转换。
                包含两个参数值，分别表示X轴和Y轴倾斜的角度，如果第二个参数为空，则默认为0，参数为负表示向相反方向倾斜。
               transform的值有20多个，如：translate，scale，rotate，skew，perspective，matrix
            */
        }

        .box:hover .box1 {
            left: 110%; /* 离父盒子左边，1.1倍box1的宽的距离 */
            transition: all .1s;
        }

        .box:hover {
            transform: translateY(-20px); /* Hover往上提升20px 坐标原点是左下角，Y轴与笛卡尔坐标正负相反 */
            box-shadow: 0 26px 40px -24px rgb(0 36 100 / 50%);
        }

        .box3 {
            float: right;
            margin-right: 15px;
            margin-top: 14px;
            font-size: 23px;
            transform: skew(30deg); /* 矫正文字因box1扭曲带来的变形*/
        }

        .box4 {
            position: absolute; /* 绝对定位固定在底边 */
            bottom: 0;
            transform: skew(30deg); /* 矫正文字因box1扭曲带来的变形*/
            margin-left: 10px;
            margin-bottom: 5px;
            font-size: 28px;
        }
    </style>
</head>

<body>
    <div class="box">
        <div class="box1">
            <div class="box3">战</div>
            <div class="box4">战</div>
        </div>
    </div>
</body>

</html>
```
