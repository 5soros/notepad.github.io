---
title: 你未必知道的个CSS知识点(全)
date: 2023-12-28 21:13:28
categories: 
  - web前端
tags: 
  - CSS
---
## 你未必知道的个CSS知识点(全)

[原文1](https://juejin.cn/post/6844903902123393032)
[原文2](https://juejin.cn/post/6844903960386469895)
原文作者：[老姚](https://juejin.cn/user/78820536232855)

第一季：
## CSS技巧篇

#### 01.【负边距】💘负边距的效果。注意左右负边距表现并不一致。左为负时，是左移，右为负时，是左拉。上下与左右类似

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/1.gif)

#### 02.【shape-outside】❤不要自以为是了。你以为自己是方的，在别人眼里你却是圆的

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/2.gif)

#### 03.【BFC应用】💓BFC应用之阻止外边距合并（margin collapsing）

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/3.gif)

#### 04.【BFC应用】💔BFC应用之消除浮动的影响

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/4.gif)

#### 05.【flex不为人知的特性之一】💕flex布局下margin:auto的神奇用法

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/5.gif)

#### 06.【flex不为人知的特性之二】💖flex布局，当flex-grow之和小于1时，只能按比例分配部分剩余空间，而不是全部

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/6.gif)

#### 07.【input的宽度】💗并不是给元素设置display:block就会自动填充父元素宽度。input 就是个例外，其默认宽度取决于size特性的值

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/7.gif)

#### 08.【定位特性】💙绝对定位和固定定位时，同时设置 left 和 right 等同于隐式地设置宽度

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/8.gif)

#### 09.【层叠上下文】💚层叠上下文：小辈就是小辈，再厉害也只是个小辈

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/9.gif)

#### 10.【粘性定位】💛position:sticky，粘性定位要起作用，需要设置最后滞留位置。chrome有bug，firefox完美

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/10.gif)

#### 11.【相邻兄弟选择器】💜相邻兄弟选择器之常用场景

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/11.gif)

#### 12.【模态框】🖤要使模态框背景透明，用rgba是一种简单方式

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/12.gif)

#### 13.【三角形】💝css绘制三角形的原理

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/13.gif)

#### 14.【table布局】💞display:table实现多列等高布局

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/14.gif)

#### 15.【颜色对比度】❣蓝底红字，由于颜色对比度比较低，故而看不清，因此不是好的配色方案😂

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/15.gif)

#### 16.【定宽高比】♥css实现定宽高比的原理：padding的百分比是相对于其包含块的宽度，而不是高度

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/16.gif)

#### 17.【动画方向】🐹动画方向可以选择alternate，去回交替进行

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/17.gif)

#### 18.【线性渐变应用】🐮css绘制彩带的原理

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/18.gif)

#### 19.【隐藏文本】🐯隐藏文字内容的两种办法

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/19.gif)

#### 20.【居中】🐰实现居中的一种简单方式

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/20.gif)

#### 21.【角向渐变】🐲新的渐变：角向渐变。可以用来实现饼图

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/21.gif)

#### 22.【背景位置百分比】🐍background-position百分比的正确理解方式：图片自身的百分比位置与容器同样的百分比位置重合

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/22.gif)

#### 23.【背景重复新值】🐴background-repeat新属性值：round和space。前者表示凑个整，后者表示留点缝

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/23.gif)

#### 24.【背景附着】🐐background-attachment指定背景如何附着在容器上，注意其属性值local和fixed的使用

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/24.gif)

#### 25.【动画延时】🐵动画添加延迟时间可以使步调不一致

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/25.gif)

#### 26.【outline使用】🐔可以使用outline来描边，不占地方，它甚至可以在里面

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/26.gif)

#### 27【背景定位】🐶当固定背景不随元素滚动时，背景定位是相对于视口的

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/27.gif)

#### 28【tab-size】🐷浏览器默认显示tab为8个空格，tab-size可以指定空格长度

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/28.gif)

#### 29【动画暂停】🥝CSS动画其实是可以暂停的

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/29.gif)

#### 30【object-fit】🍓图片在指定尺寸后，可以设置object-fit为contain或cover保持比例

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/30.gif)

#### 31【鼠标状态】🍒按钮禁用时，不要忘了设置鼠标状态

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/31.gif)

#### 32【背景虚化】🍑使用CSS滤镜实现背景虚化

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/32.gif)

#### 33【fill-available】🍏设置宽度为fill-available，可以使inline-block像block那样填充整个空间

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/33.gif)

#### 34【fit-content】🍎设置宽度为fit-content，可以使block像inline-block那样实现收缩宽度包裹内容的效果

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/34.gif)

#### 35【自定义属性】🍋CSS自定义属性的简单使用

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/35.gif)

#### 36【min-content/max-content】🍍可以设置宽度为min-content和max-content，前者让内容尽可能地收缩，后者让内容尽可能地展开

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/36.gif)

#### 37【进度条】🍊使用渐变，一个div实现进度条

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/37.gif)

#### 38【打印】🍉可以在打印网页时，设置page相关属性。比如page-break-before属性来表示是否需要另起新页

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/38.gif)

#### 39【逐帧动画】🍌利用CSS精灵实现逐帧动画

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/39.gif)

#### 40【resize】🍐普通元素也可以像textarea那样resize

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/40.gif)

#### 41【面包屑】🍇使用before伪元素实现面包屑

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/41.gif)

#### 42【sticky footer】🍈使用grid布局实现sticky footer

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/42.gif)

#### 43【动画填充状态】🍅CSS可以设置动画开始前和结束时所保持的状态

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/43.gif)

#### 44【动画负延迟】🥑CSS动画可以设置延迟时间为负数，表示动画仿佛开始前就已经运行过了那么长时间

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/44.gif)

#### 45【过渡】🍆爱的魔力转圈圈

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/45.gif)

#### 46【动画案例】🍬水波效果原理

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/46.gif)

#### 47【动画案例】🌸CSS弹球动画效果的原理

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/47.gif)

#### 48【outline】🌻outline属性的妙用

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/48.gif)

#### 49【grid】💕火狐浏览器grid布局检测器

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/49.gif)

第二季：
## 知识点篇

#### 01.🔢CSS计数器的使用

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/1.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/gOYrmaq)

#### 02.📝文本缩进，块级用text-indent，内联用margin-left

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/2.png)

#### 03.📖美化表格常用技巧。等比、定宽、错色等

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/3.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/NWKRBzY)

#### 04.👔滚动条样式美化

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/4.png)

#### 05.👉使用文本对齐属性值justify，实现类似弹性布局的space-between效果

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/5.png)

#### 06.🐠使用selection选择器自定义文本选区的高亮样式

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/6.png)

#### 07.🏩grid-template设置网格模板，实现三列两行布局

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/7.png)

#### 08.🏠grid-gap设置网格间隙，包括行和列

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/8.png)

#### 09.🏡grid布局，使用fr单位实现等比例分配空间。fr是分数（fraction）的缩写

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/9.png)

#### 10.🏢grid布局使用repeat函数，可以少写些代码

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/10.png)

#### 11.🍧focus-within是为数不多的一个，可以由子操作父选择器

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/11.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/ZgRyeg)

#### 12.♐容易被忽视的target选择器

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/12.png)

## 特效原理篇

#### 13.⚽使用变换实现简单复合运动

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/13.png)

#### 14.🌈看见彩虹，吃定彩虹

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/14.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/NWKXKYd?editors=0110)

#### 15.🙅人脸识别时用到的扫描图，之前我司的一个需求

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/15.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/MWgGzWb)

#### 16.🗿立体感按钮

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/16.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/LweeBp)

#### 17.🔄实现一个混沌动态背景

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/17.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/OJLRLPL)

#### 18.💞环绕椭圆轨道旋转。平移运动与圆周运动复合就能做到

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/18.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/MWgGWYm)

#### 19.👓只用background就能实现简单滤镜效果

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/19.png)

#### 20.🐍蛇形边框特效原理

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/20.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/gOYgGYj)

#### 21.🎁让你的女朋友动起来

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/21.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/bGbWzvm)

#### 22.🌖一个div，实现天狗吃月亮

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/22.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/qBWqmbp)

#### 23.🌖更简单的方案，实现天狗吃月亮

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/23.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/ZEzBPWr)

#### 24.🌌画个土星，像不像三分样

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/24.png)

演示地址1：[codepen](https://codepen.io/laoyao/pen/BaBRjzp)

演示地址2：[codepen](https://codepen.io/laoyao/pen/VwZbBbG)

#### 25.🌈使用渐变，一个div画Chrome的logo

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/25.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/KOvZOd)

#### 26.🉐一个div简单画铜钱

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/26.png)

#### 27.🃏切牌特效原理

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/27.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/XWrgVWV)

#### 28.✂给clip-path应用动画

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/28.png)

演示地址：[codepen](https://codepen.io/laoyao/pen/wvwgvoz)

## 工具篇

#### 29.🚀vscode里是可以使用Emmet语法的，敲tab键结束命令，^表示返回上一层级

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/29.png)

[语法说明](https://docs.emmet.io/abbreviations/syntax/)

#### 30.⛲查看页面布局小技巧，觉得很好用

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/CSS-knowledge-points-that-you-may-not-know/S2/30.png)

[书签完整代码](https://codepen.io/laoyao/pen/gOOaOXM?editors=0010)
