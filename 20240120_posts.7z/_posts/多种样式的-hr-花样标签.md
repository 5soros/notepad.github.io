---
title: 多种样式的<hr>花样标签
date: 2023-12-17 20:23:45
categories: 
  - web前端
tags: 
  - CSS
---
## 666，看hr标签实现分隔线如何玩出花




日常开发经常会用到网页分隔线，例如列表下拉到最后，类似于“我是有底线的”这样的提示，就会伴随分隔线。

通常，这样的分隔线是使用`<div>`标签模拟的，其实我们可以使用语义更好的`<hr>`标签模拟。

HTML `<hr>`元素虽然是一个非闭合标签，但是也是支持`::before`和`::after`伪元素的。

因此，我们可以使用`<hr>`标签实现各种样式的分隔线效果。

### 一、基础分隔线效果

##### 实线

相关HTML和CSS代码如下所示：

```markup
<hr class="hr-solid">
```

```markup
.hr-solid {
    border: 0;
    border-top: 1px solid #d0d0d5;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/1.png)

##### 点线（1px和2px）

相关HTML和CSS代码如下所示，使用的是浏览器默认效果，因此，不同浏览器下看到的虚点的细节可能会有所差异：

```markup
<hr class="hr-dotted">
<hr class="hr-dotted2">
```

```markup
.hr-dotted {
    border: 0;
    border-top: 1px dotted #a2a9b6;
}
.hr-dotted2 {
    border: 0;
    border-top: 2px dotted #a2a9b6;
}
```
渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/2.png)


##### 虚线（1px和2px）

相关HTML和CSS代码如下所示，同样的，浏览器默认虚线样式，不同浏览器表现细节有差异：

```markup
<hr class="hr-dashed">
<hr class="hr-dashed2">
```

```markup
.hr-dashed {
    border: 0;
    border-top: 1px dashed #a2a9b6;
}
.hr-dashed2 {
    border: 0;
    border-top: 2px dashed #a2a9b6;
}
```
渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/3.png)



##### 双实线

相关HTML和CSS代码如下所示：

```markup
<hr class="hr-double">
```

```markup
.hr-double {
    border: 0;
    border-top: 3px double #d0d0d5;
}
```
渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/4.png)


##### 疏密可控的虚线

这里使用线性渐变模拟虚线效果，优点是虚线的虚实比例是可以精确控制的，实现原理和细节以前介绍过，可参见“[CSS3 linear-gradient线性渐变实现虚线](https://www.zhangxinxu.com/wordpress/?p=6494)”一文。

现在有如下所示的HTML和CSS代码：

```markup
<hr class="hr-dashed-fixed">
```

```markup
.hr-dashed-fixed {
    border: 0;
    padding-top: 1px;
    background: repeating-linear-gradient(to right, #a2a9b6 0px, #a2a9b6 4px, transparent 0px, transparent 10px);
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/5.png)

这里，为了方便大家使用，我又使用CSS变量，把虚线实线比例做成可配置的了。

其中`--dashed-filled`是实线尺寸，变量`--dashed-filled`是虚线的尺寸，代码示意：

```markup
<hr class="hr-dashed-fixed" style="--dashed-filled: 6px; --dashed-open: 5px;">
```

```markup
.hr-dashed-fixed {
    border: 0;
    padding-top: 1px;
    /* for 现代浏览器 */
    background: repeating-linear-gradient(to right, #a2a9b6 0 var(--dashed-filled, 4px), transparent 0 calc(var(--dashed-filled, 4px) + var(--dashed-open, 6px)));
}
```

只有在现代浏览器中才有效果，因为IE不支持CSS变量，因此，IE浏览器无效。

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/6.png)

为了全兼容，大家可以把上面两段CSS合二为一，例如：

```markup
.hr-dashed-fixed {
    border: 0;
    padding-top: 1px;
    /* for IE浏览器 */
    background: repeating-linear-gradient(to right, #a2a9b6 0px, #a2a9b6 4px, transparent 0px, transparent 10px);
    /* for 现代浏览器 */
    background: repeating-linear-gradient(to right, #a2a9b6 0 var(--dashed-filled, 4px), transparent 0 calc(var(--dashed-filled, 4px) + var(--dashed-open, 6px)));
}
```

##### 两头虚的分隔线

这是个比较常见的分隔线效果，线的两端淡出，中间是完整的颜色。

此效果实现方法很多，我这里使用的是CSS渐变模拟的，相关HTML和CSS代码如下所示：

```markup
<hr class="hr-edge-weak">
```

```markup
.hr-edge-weak {
    border: 0;
    padding-top: 1px;
    background: linear-gradient(to right, transparent, #d0d0d5, transparent);
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/7.png)

##### 斜纹分隔线

有时候需要分界线更加明显的分隔线，则可以试试下面的代码，对应的效果是斜纹分隔线。

```markup
<hr class="hr-twill">
```

```markup
.hr-twill {
    border: 0;
    padding: 3px;
    background: repeating-linear-gradient(135deg, #a2a9b6 0px, #a2a9b6 1px, transparent 1px, transparent 6px);
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/8.png)

我们也可以让斜纹表现为多彩的颜色，这里使用了遮罩实现，HTML和CSS代码为：

```markup
<hr class="hr-twill-colorful">
```

```markup
/* 现代浏览器only */
.hr-twill-colorful {
    border: 0;
    padding: 3px;
    background: linear-gradient(135deg, red, orange,green, blue, purple);
    --mask-image: repeating-linear-gradient(135deg, #000 0px, #000 1px, transparent 1px, transparent 6px);
    -webkit-mask-image: var(--mask-image);
    mask-image: var(--mask-image);
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/9.png)

##### 波浪线

这里的波浪线实现使用了特别的技巧，相关原理和细节之前专门撰文介绍过，详见：“[CSS text-decoration实现宽度100%波浪线效果](https://www.zhangxinxu.com/wordpress/?p=9333)”。

这里演示使用的前端代码则是：

```markup
<hr class="hr-wavy">
```

```markup
.hr-wavy {
    border: 0;
    color: #d0d0d5;
    height: .5em;
    white-space: nowrap;
    letter-spacing: 100vw;
    padding-top: .5em;
}
.hr-wavy::before {
    content: "\2000\2000";
    /* IE浏览器实线代替 */
    text-decoration: overline;
    /* 现代浏览器 */
    text-decoration: overline wavy;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/10.png)

##### 阴影线

这个实现比较简单，就是使用CSS `box-shadow`盒阴影属性，多用在表示层次的分隔场景中。

相关HTML和CSS代码如下所示：

```markup
<hr class="hr-shadow">
```

```markup
.hr-shadow {
    border: 0;
    padding-top: 10px;
    color: #d0d0d5;
    border-top: 1px solid rgba(0,0,0,.1);
    box-shadow: inset 0 10px 10px -10px;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/11.png)

### 二、带点图形装饰的分隔线

这里主要演示几个生产环境可以使用的几个样式，那些花里胡哨的分隔线这里就不展示了。

##### 中间有装饰

中间有一些图形或图像，实现原理大同小异，这里使用圆和方块抛砖引玉示意下。

```markup
<hr class="hr-mid-circle">
<hr class="hr-mid-square">
```

这里的线条使用CSS渐变绘制，而中间的图形就需要借助伪元素实现了。

```markup
.hr-mid-circle,
.hr-mid-square {
    border: 0;
    color: #d0d0d5;
    background: linear-gradient(currentColor, currentColor) no-repeat center;
    background-size: 100% 1px;
}
.hr-mid-circle::before {
    content: '';
    display: block;
    width: .75em; height: .75em;
    border-radius: 50%;
    background-color: currentColor;
    margin: auto;
}
.hr-mid-square::before {
    content: '';
    display: block;
    width: .75em; height: .75em;
    transform: rotate(45deg);
    background-color: currentColor;
    margin: 3px auto;
}
```


渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/12.png)

##### 中间有多个装饰

如果中间是多个圆，多个方块，那该怎么办呢？

一种方法是变成背景图，平铺，在本例中，因为是实色图形，则可以使用 `box-shadow` 进行图形复制。

```markup
<hr class="hr-mid-circle" multiple>
<hr class="hr-mid-square" multiple>
```

只需要在上面CSS代码基础上加上下面这几行CSS就可以了：

```markup
.hr-mid-circle[multiple]::before {
    box-shadow: 1.5em 0, -1.5em 0;
}
.hr-mid-square[multiple]::before {
    box-shadow: 1.25em -1.25em, -1.25em 1.25em;;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/13.png)

##### 装饰在两端

装饰有可能在两端，而不是中间，这里演示一个钻石图形在两侧对齐的例子，HTML和CSS使用的是：

```
<hr class="hr-space-square">
```

```markup
.hr-space-square {
    border: 0;
    color: #d0d0d5;
    background: linear-gradient(currentColor, currentColor) no-repeat center;
    background-size: calc(100% - 1.5em - 6px) 1px;
    display: flex;
    justify-content: space-between;
}
.hr-space-square::before,
.hr-space-square::after {
    content: '';
    display: block;
    width: .75em; height: .75em;
    transform: rotate(45deg);
    box-sizing: border-box;
    border: 1px solid;
    margin: 3px;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/14.png)

##### 装饰复杂一点点

就是线条多一点，图形的造型也稍微复杂一点的装饰效果，HTML比较简单：

```markup
<hr class="hr-double-arrow">
```

CSS这里用到了定位还有一些常见的CSS图形生成技巧：

```markup
.hr-double-arrow {
    color: #d0d0d5;
    border: double;
    border-width: 3px 5px;
    border-color: #d0d0d5 transparent;
    height: 1px;
    overflow: visible;
    margin-left: 20px;
    margin-right: 20px;
    position: relative;
}
.hr-double-arrow:before, 
.hr-double-arrow:after {
    content: '';
    position: absolute;
    width: 5px; height: 5px;
    border-width: 0 3px 3px 0;
    border-style: double;
    top: -3px;
    background: radial-gradient(2px at 1px 1px, currentColor 2px, transparent 0) no-repeat;
}
.hr-double-arrow:before {
    transform: rotate(-45deg);
    left: -20px;
}
.hr-double-arrow:after {
    transform: rotate(135deg);
    right: -20px;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/15.png)



还有其他一些装饰效果，例如一些星星啊，加一些花朵之类的，篇幅原因（实际上懒得折腾，需要使用SVG图形），就不展示了。

### 三、带文字内容的分隔线

这个可能用得更多一点，然后这里演示的效果CSS代码都大同小异，因此有些重复的CSS就不再展示了。

##### 两端实线

HTML代码这样的：

```markup
<hr class="hr-solid-content" data-content="分隔线">
<hr class="hr-solid-content" data-content="文字自适应，背景透明">
```

CSS代码如下，这里的实现还是需要点基本功的，因为要让左右图形自适应于文字内容，同时文字后面不能有背景色。

```markup
.hr-solid-content {
    color: #a2a9b6;
    border: 0;
    font-size: 12px;
    padding: 1em 0;
    position: relative;
}
.hr-solid-content::before {
    content: attr(data-content);
    position: absolute;
    padding: 0 1ch;
    line-height: 1px;
    border: solid #d0d0d5;
    border-width: 0 99vw;
    width: fit-content;
    /* for 不支持fit-content浏览器 */
    white-space: nowrap;
    left: 50%;
    transform: translateX(-50%);
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/16.png)

##### 两端虚线

实现原理和上面实线有些类似，也是使用一个巨大的边框，但是，此时使用dashed虚线边框是没有效果的，因为边框宽度太宽，高度为0，虚线的渲染是按照比例来的。

这里我是使用的`border-image`配合重复线性渐变模拟的虚线边框效果，HTML代码为：

```markup
<hr class="hr-dashed-content" data-content="分隔线">
```

CSS代码，`.hr-dashed-content`需要的CSS代码和上面`.hr-solid-content`一模一样，然后，额外增加下面这行CSS：

```markup
.hr-dashed-content::before {
    border-image: repeating-linear-gradient(90deg, #d0d0d5, #d0d0d5 1px, transparent 1px, transparent 2px) 0 85% / / 0 repeat;
}
```

上面的语法看不懂没关系，知道上面代码有效果就可以了，然后85%修改可以控制虚线的尺寸大小。

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/17.png)

##### 两端淡出

代码：

```markup
<hr class="hr-fade-content" data-content="分隔线">
```

在原来实线效果基础上使用渐变作为遮罩就可以实现这样的效果了：

```markup
// ... 一致代码略
.hr-fade-content {
    -webkit-mask-image: linear-gradient(to right, transparent, black, transparent);
    mask-image: linear-gradient(to right, transparent, black, transparent);
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/18.png)

##### 内容装饰

如果希望内容用框框起来，加个背景什么的，则需要借助另外一个伪元素，因为`::before`的尺寸高度被限制在了1px, 此时只能`::after`伪元素出马，同样不展示一致的CSS代码。

```markup
<hr class="hr-mid-border-content" data-content="分隔线">
```

```markup
.hr-mid-border-content::after{
    content: attr(data-content);
    position: absolute;
    padding: 4px 1ch;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    color: transparent;
    border: 1px solid #d0d0d5;
}
```

渲染效果如下：

![](https://raw.githubusercontent.com/5soros/blogs-photos/main/hr-css-lines/19.png)

### 四、专门弄了个项目开源了

一个人再怎么想破脑袋，所能实现的且实用的分隔线效果也是有限的，此时，就需要大家的智慧了。

因此，我专门在gitee上把相关CSS代码都开源出去了。

项目地址是：<https://gitee.com/zhangxinxu/css-hr>
原文：https://www.zhangxinxu.com/wordpress/2021/05/css-html-hr/
参见：一些相当华丽的 hr 装饰效果：https://css-tricks.com/examples/hrs/

